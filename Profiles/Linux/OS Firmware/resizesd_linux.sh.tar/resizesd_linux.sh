#!/bin/bash

DRIVE=$1
echo "[Resize filesystems...]"

rootfs_start=`fdisk -u -l ${DRIVE} | grep ${DRIVE}p2 | awk '{print $2}'`

# Create partition table for extend root file system (/dev/mmcblk1p2) partition
fdisk -u $DRIVE << EOF &>/dev/null
d
2
n
p
2
$rootfs_start

w
EOF

if [ -x /sbin/partprobe ]; then
    /sbin/partprobe ${DRIVE} &> /dev/null
else
    sleep 1
fi

e2fsck -f -y ${DRIVE}p2 &> /dev/null
resize2fs ${DRIVE}p2 &> /dev/null

if [ -x /sbin/partprobe ]; then
    /sbin/partprobe ${DRIVE} &> /dev/null
else
    sleep 1
fi

echo 7 > /proc/sys/kernel/printk
echo "[Done]"

